This a part of the Piecemaker Library pared down to only include the pieces need for the Drupal Piecemaker module.
This current version is for the 7.x-1.x branch of the module.

To download the full package including the Flash source, visit:

http://www.modularweb.net/#/en/piecemaker

or

http://active.tutsplus.com/freebies/exclusive/exclusive-freebie-the-piecemaker-2/
